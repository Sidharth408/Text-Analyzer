from flask import Flask, render_template, request
import re
import spacy
import matplotlib.pyplot as plt
import io
import base64
import nltk
import language_tool_python
from spellchecker import SpellChecker
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from rake_nltk import Rake
from nltk.tokenize import sent_tokenize
import enchant  # Import pyenchant for spelling correction

# Download necessary NLTK data
nltk.download("punkt")

# Initialize Flask app
app = Flask(__name__)

# Load NLP tools
nlp = spacy.load("en_core_web_sm")
analyzer = SentimentIntensityAnalyzer()
spell = SpellChecker()
rake = Rake()
tool = language_tool_python.LanguageTool('en-US')

# Initialize pyenchant dictionary
en_dict = enchant.Dict("en_US")

def preprocess_text(text):
    """Clean and preprocess text while maintaining sentence structure."""
    text = re.sub(r"[^a-zA-Z0-9.,!?;:\'\"\s]", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def sentiment_analysis(text):
    """Analyze text sentiment using Vader."""
    scores = analyzer.polarity_scores(text)
    return scores

def extract_keywords(text):
    """Extract top 5 keywords using RAKE."""
    rake.extract_keywords_from_text(text)
    return rake.get_ranked_phrases()[:5]

def extract_named_entities(text):
    """Extract named entities using spaCy."""
    doc = nlp(text)
    return [(ent.text, ent.label_) for ent in doc.ents]

def text_statistics(text):
    """Compute text statistics."""
    return {
        "num_chars_including_spaces": len(text),
        "num_chars_without_spaces": len(text.replace(" ", "")),
        "num_words": len(text.split()),
        "num_sentences": len(sent_tokenize(text))
    }

def correct_spelling(text):
    """Enhanced spelling correction using pyenchant, SpellChecker, and LanguageTool."""
    # Step 1: Correct spelling with pyenchant
    words = text.split()
    corrected_words = [
        en_dict.suggest(word)[0] if not en_dict.check(word) and en_dict.suggest(word) else word for word in words
    ]
    corrected_text = " ".join(corrected_words)

    # Step 2: Correct remaining errors with SpellChecker
    words = corrected_text.split()
    corrected_words = [
        spell.correction(word) if spell.correction(word) and spell.correction(word) != word else word
        for word in words
    ]
    corrected_text = " ".join(corrected_words)

    # Step 3: Apply grammar and additional spelling fixes with LanguageTool
    try:
        matches = tool.check(corrected_text)
        corrected_text = language_tool_python.utils.correct(corrected_text, matches)
    except Exception as e:
        print("LanguageTool Error:", str(e))

    return corrected_text

def generate_sentiment_plot(sentiment_scores):
    """Generate a bar chart for sentiment analysis."""
    labels = ["Positive", "Neutral", "Negative"]
    values = [sentiment_scores["pos"], sentiment_scores["neu"], sentiment_scores["neg"]]
    plt.figure(figsize=(6, 4))
    plt.bar(labels, values, color=["green", "blue", "red"])
    plt.xlabel("Sentiment Categories")
    plt.ylabel("Score")
    plt.title("Sentiment Distribution")
    img = io.BytesIO()
    plt.savefig(img, format="png")
    img.seek(0)
    return base64.b64encode(img.getvalue()).decode()

def generate_text_statistics_plot(stats):
    """Generate a bar chart for text statistics with clear labels."""
    labels = ["Char\n(w/o spaces)", "Char\n(w/ spaces)", "Words", "Sentences"]
    values = [stats["num_chars_without_spaces"], stats["num_chars_including_spaces"], stats["num_words"], stats["num_sentences"]]
    plt.figure(figsize=(6, 4))
    plt.bar(labels, values, color=["purple", "orange", "blue", "red"])
    plt.xticks(rotation=0)
    plt.xlabel("Text Features")
    plt.ylabel("Count")
    plt.title("Text Statistics")
    img = io.BytesIO()
    plt.savefig(img, format="png")
    img.seek(0)
    return base64.b64encode(img.getvalue()).decode()

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        text = request.form["text"]
        preprocessed_text = preprocess_text(text)
        sentiment = sentiment_analysis(text)
        keywords = extract_keywords(text)
        entities = extract_named_entities(text)
        stats = text_statistics(text)
        improved_text = correct_spelling(text)  # Spelling correction is performed last
        sentiment_plot = generate_sentiment_plot(sentiment)
        stats_plot = generate_text_statistics_plot(stats)

        return render_template(
            "analysis.html",
            text=text,
            preprocessed_text=preprocessed_text,
            sentiment=sentiment,
            keywords=keywords,
            entities=entities,
            stats=stats,
            improved_text=improved_text,
            sentiment_plot=sentiment_plot,
            stats_plot=stats_plot,
        )

    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
